$(document).ready(function () {
  console.log("1111");

  let messageLength = 2;

  $(".sendBtn").on("click", function (e) {
    e.preventDefault();
    var nickname = $(".nickname").val();
    var content = $(".content").val();
    console.log("nickname", nickname);
    console.log("content", content);

    if (nickname && content) {
      var newMessage = `
        <div class="message">
          <img src="./img/avatar.png" alt="" />
          <div class="msgRight">
            <p>${nickname}<span class="btnDelete">x</span></p>
            <p>${content}</p>
          </div>
        </div>
      `;

      $(".messageContainer").append(newMessage);
      messageLength = messageLength + 1;
      $(".messageLength").text(`${messageLength}`);
      $(".nickname").val("");
      $(".content").val("");
    } else {
      alert("请填写昵称和内容");
    }
  });

  $(".messageContainer").on("click", ".btnDelete", function () {
    messageLength = messageLength - 1;
    $(".messageLength").text(`${messageLength}`);
    $(this).closest(".message").remove();
  });
});
